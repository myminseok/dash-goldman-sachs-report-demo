$( document ).ready(function() {
	setTimeout(function(){
		$( ".button" ).click(function() {
  			window.print();
		});
	}, 4000);
});
